const XAPI = (typeof browser !== "undefined") ? browser : chrome;
const $ = (id) => document.getElementById(id);
const sset = (o) => new Promise(r => XAPI.storage.local.set(o, r));
const sget = (k) => new Promise(r => XAPI.storage.local.get(k, v => r(v[k])));

// restore settings
Promise.all([sget("apiKey"), sget("model"), sget("rateIn"), sget("rateOut")]).then(([k, m, ri, ro]) => {
  if (k) { $("key").value = k; $("out").textContent = "Ready."; $("run").disabled = false; $("setup").open = false; }
  if (m) $("model").value = m;
  if (ri) $("rin").value = ri;
  if (ro) $("rout").value = ro;
});

$("key").addEventListener("change", async e => { await sset({ apiKey: e.target.value.trim() || undefined }); const ok = !!e.target.value.trim(); $("run").disabled = !ok; if (ok) $("out").textContent = "Ready."; });
$("model").addEventListener("change", e => sset({ model: e.target.value }));
$("rin").addEventListener("change", e => sset({ rateIn: e.target.value || undefined }));
$("rout").addEventListener("change", e => sset({ rateOut: e.target.value || undefined }));

$("run").addEventListener("click", async () => {
  const task = $("q").value.trim(); if (!task) return;
  const model = $("model").value;
  $("run").disabled = true; $("out").textContent = "Running via Anthropic API…";
  try {
    const { envelope, model: m, floorSource, stop_reason } = await Interpreter.run(task, model);
    $("out").textContent = `# model: ${m} · floor: ${floorSource}${stop_reason ? " · stop_reason: " + stop_reason : ""}\n\n` + JSON.stringify(envelope, null, 2);
  } catch (e) {
    $("out").textContent = "⚠ " + e.message;
  } finally {
    $("run").disabled = false;
  }
});
