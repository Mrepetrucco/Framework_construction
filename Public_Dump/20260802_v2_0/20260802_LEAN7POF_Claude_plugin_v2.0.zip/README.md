# LEAN7POF Claude Interpreter — browser plugin (Anthropic API)

The LEAN variant of the keyless plugin: same architecture, but it runs on **your Anthropic Claude API key** under the **LEAN7POF v1.3** floor (the full Claude-native lean projection — not the reduced external LEAN7POF2 edition).

It:
1. bundles **`floor.md` = LEAN7POF v1.3** (§0 session-open + v0.1 core + L2–L14) — loaded locally, since LEAN7POF is not public,
2. sends your task to the **Anthropic Messages API** (`/v1/messages`) with your key, under the floor as the system prompt,
3. screens the answer with the **embedded Reconciler** — J2 trap-scan, R1 unverified-downgrade, unresolved-never-empty, **safeguard-refusal handling**,
4. emits a governed **Z-block envelope** with a real **API-cost meter** from the response's token usage, and logs it locally.

## Differences vs the keyless (LEAN7POF2) build
| | Keyless (LEAN7POF2) | This (LEAN7POF · Claude) |
|---|---|---|
| Floor | LEAN7POF2 (fetched from Public_Dump) | **LEAN7POF v1.3 (bundled)** |
| Engine | on-device Prompt API / Gemini key | **Anthropic Messages API (your key)** |
| Judgment set | reduced R1–R7 | full lean L-clauses + J-screen |
| Refusal handling | n/a | **stop_reason=refusal → distinct state + enablement ladder** |
| Meter | on-device (no cost) | **API cost from usage tokens** |

## Install
- **Chrome:** `chrome://extensions` → Developer mode → Load unpacked → this folder.
- **Edge:** `edge://extensions` → Developer mode → Load unpacked → this folder.
- **Safari:** `xcrun safari-web-extension-converter /path/to/lean7pof_claude_plugin`, build once, enable in Safari → Settings → Extensions.

Then open the popup → **Settings** → paste your `ANTHROPIC_API_KEY` (from console.anthropic.com). Pick a model and Run.

## Models
Opus 4.8 (calibrated default) · Sonnet 5 · Haiku 4.5 (mechanical) · Fable 5 (focal-break; refusal-guarded). Routing follows Artifact M v3.3 — Opus for premium reasoning / documents / IP-sensitive; Fable for the confirmed win-classes under the enablement ladder; Haiku for mechanical only.

## Refusal handling (Fable-aware)
If the API returns `stop_reason: "refusal"`, the Reconciler treats it as a **safeguard-classifier event — not context-loss or a capability limit** (Protocol §4.1), and surfaces the **enablement ladder** (§4.3): retry via an output schema with word-capped fields → word-count caps → paragraph bounds; never sentence counts; after two adjusted-form refusals, route to Opus.

## Credential discipline (Artifact C §C-3 / J3)
The key is stored in this browser's **extension storage only**, sent solely to `api.anthropic.com` via the `anthropic-dangerous-direct-browser-access` header, and is **never hard-coded, logged into the session log, or committed**. Clear the Settings field to remove it.

## Notes
- Cost rates (Settings) are optional; supply $/Mtok to estimate the meter's `API` figure — ground truth is your Anthropic console (J8). Without a rate the meter reports raw token counts.
- `anthropic-dangerous-direct-browser-access: true` is required for any browser-origin call to the Anthropic API and does expose the key to this page's context — acceptable for a personal local extension, not for a shared/published one.
- Session log lives in `storage.local`; clear the extension's storage to reset.
- To update the floor, replace `floor.md` with a newer LEAN7POF head and reload the extension.
