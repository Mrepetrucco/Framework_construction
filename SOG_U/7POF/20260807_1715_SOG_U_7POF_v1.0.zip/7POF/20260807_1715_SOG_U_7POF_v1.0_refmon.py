"""20260807_1715_SOG_U_7POF_v1.0 - reference monitor (deterministic; runner-executed; no model self-report)."""

def check_7POF(ev):
    # ev: {'exemplar_present': bool, 'conformal_certainty': float}
    e1 = 1.0 if ev.get('exemplar_present') else 0.0
    e2 = float(ev.get('conformal_certainty', 0.0))
    return min(e1, e2)
