"""20260807_2255_SOG_U_7POF_v1.1 - reference monitor (v1.1; deterministic; runner-executed; no self-report)."""

def check_7POF(ev):
    ch = {}
    if "exemplar_present" in ev:
        ch["E1"] = (1.0 if ev["exemplar_present"] else 0.0, True)
    # DEFECT-10 FIX: E2 excluded (None) unless a calibration set is present
    if ev.get("calibration_set") and "conformal_certainty" in ev:
        ch["E2"] = (float(ev["conformal_certainty"]), False)
    # DEFECT-11 FIX: E3 uses cheap SEP by default; capped; excluded if not computed
    if "semantic_stability" in ev:
        ch["E3"] = (min(float(ev["semantic_stability"]), E3_CAP), False)
    return ch or {"_": (None, None)}
