"""20260807_2255_SOG_U_AX7_v1.1 - reference monitor (v1.1; deterministic; runner-executed; no self-report)."""

def check_AX7(ev):
    if "parser_pair_agree" not in ev and "intent_raised" not in ev:
        return {"_": (None, None)}
    schema = 1.0 if (ev.get("parser_pair_agree") and ev.get("schema_valid")) else 0.0
    intent = 1.0 if ev.get("intent_raised") else 0.0
    return {"E1_schema": (schema, True), "E1_intent": (intent, True)}
