"""20260807_1715_SOG_U_AX7_v1.0 - reference monitor (deterministic; runner-executed; no model self-report)."""

def check_AX7(ev):
    # ev: {'parser_pair_agree': bool, 'schema_valid': bool, 'intent_raised': bool}
    schema = 1.0 if (ev.get('parser_pair_agree') and ev.get('schema_valid')) else 0.0
    intent = 1.0 if ev.get('intent_raised') else 0.0
    return min(schema, intent)
