"""20260807_2255_SOG_U_L0_v1.1 - reference monitor (v1.1; deterministic; runner-executed; no self-report)."""

def check_L0(ev):
    # ev keys optional; absence -> not gathered -> None (ABSTAIN), not 0
    if "owner_verbatim" not in ev and "l0_id" not in ev:
        return {"E1": (None, None)}
    ok = bool(ev.get("owner_verbatim") or ev.get("l0_id"))
    return {"E1": (1.0 if ok else 0.0, True)}
