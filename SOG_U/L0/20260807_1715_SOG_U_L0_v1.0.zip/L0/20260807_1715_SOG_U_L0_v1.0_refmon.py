"""20260807_1715_SOG_U_L0_v1.0 - reference monitor (deterministic; runner-executed; no model self-report)."""

def check_L0(ev):
    # ev: {'owner_verbatim': bool, 'l0_id': str|None}
    return 1.0 if (ev.get('owner_verbatim') or ev.get('l0_id')) else 0.0
