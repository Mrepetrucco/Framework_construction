"""20260807_1715_SOG_U_BX1_v1.0 - reference monitor (deterministic; runner-executed; no model self-report)."""

def check_BX1(ev):
    # ev: {'runner_settled': bool, 'ch_kl_suitable': bool, 'concordance': float, 'rho_wrong': float}
    e1 = 1.0 if ev.get('runner_settled') else 0.0
    if ev.get('ch_kl_suitable'):
        e4 = float(ev.get('concordance',0.0)) * (1.0 - float(ev.get('rho_wrong',1.0)))
    else:
        e4 = 1.0  # not applicable -> does not lower the min
    return min(e1, e4)

def check_L0(ev):
    # ev: {'owner_verbatim': bool, 'l0_id': str|None}
    return 1.0 if (ev.get('owner_verbatim') or ev.get('l0_id')) else 0.0

def check_7POF(ev):
    # ev: {'exemplar_present': bool, 'conformal_certainty': float}
    e1 = 1.0 if ev.get('exemplar_present') else 0.0
    e2 = float(ev.get('conformal_certainty', 0.0))
    return min(e1, e2)

def check_AX7(ev):
    # ev: {'parser_pair_agree': bool, 'schema_valid': bool, 'intent_raised': bool}
    schema = 1.0 if (ev.get('parser_pair_agree') and ev.get('schema_valid')) else 0.0
    intent = 1.0 if ev.get('intent_raised') else 0.0
    return min(schema, intent)


# ================= MASTER GATE (hosted at BX1) =================
FLOOR = 0.99865
DELTA = 0.05

def compose(cert_by_level):
    "Star-grounded composition: C = min over levels (NOT product)."
    return min(cert_by_level.values())

def gate(cert_by_level, claimed_precision):
    """Fail-closed emission gate. Returns one of EMIT/RAISE/CONTAIN/ABSTAIN with the limiting level.
    cert_by_level: dict level->certainty in [0,1] (None = no computable channel).
    claimed_precision (pi): narrowness/confidence the output signals, in [0,1].
    """
    if any(v is None for v in cert_by_level.values()):
        return {"exit": "ABSTAIN", "reason": "no computable channel at some level"}
    C = compose(cert_by_level)
    limiting = min(cert_by_level, key=cert_by_level.get)
    if claimed_precision > C + DELTA:
        return {"exit": "CONTAIN", "reason": "obfuscation: pi>s+delta", "pi": claimed_precision, "s": C}
    if C >= FLOOR:
        return {"exit": "EMIT", "C": C}
    return {"exit": "RAISE", "C": C, "limiting_level": limiting,
             "cognitive_forcing": "show C + limiting level; require justification-for-acceptance"}

if __name__ == "__main__":
    demo = {"L0": check_L0({"owner_verbatim": True}),
            "7POF": check_7POF({"exemplar_present": True, "conformal_certainty": 0.999}),
            "AX7": check_AX7({"parser_pair_agree": True, "schema_valid": True, "intent_raised": True}),
            "BX1": check_BX1({"runner_settled": True, "ch_kl_suitable": False})}
    print("cert_by_level:", demo)
    print("gate (pi=0.99):", gate(demo, 0.99))
    print("gate (pi=0.90):", gate(demo, 0.90))
    # obfuscation demo: high claimed precision, low support
    weak = dict(demo); weak["7POF"] = 0.5
    print("obfuscation demo (pi=0.99, weak 7POF):", gate(weak, 0.99))
