"""20260807_2255_SOG_U_BX1_v1.1 - reference monitor (v1.1; deterministic; runner-executed; no self-report)."""

def check_BX1(ev):
    ch = {}
    if "runner_settled" in ev:
        ch["E1"] = (1.0 if ev["runner_settled"] else 0.0, True)
    # DEFECT-1 FIX: not-applicable E4 is EXCLUDED (None), never 1.0
    if ev.get("ch_kl_suitable") and "concordance" in ev:
        ch["E4"] = (float(ev["concordance"])*(1.0-float(ev.get("rho_wrong",1.0))), False)
    return ch or {"_": (None, None)}

def check_L0(ev):
    # ev keys optional; absence -> not gathered -> None (ABSTAIN), not 0
    if "owner_verbatim" not in ev and "l0_id" not in ev:
        return {"E1": (None, None)}
    ok = bool(ev.get("owner_verbatim") or ev.get("l0_id"))
    return {"E1": (1.0 if ok else 0.0, True)}

def check_7POF(ev):
    ch = {}
    if "exemplar_present" in ev:
        ch["E1"] = (1.0 if ev["exemplar_present"] else 0.0, True)
    # DEFECT-10 FIX: E2 excluded (None) unless a calibration set is present
    if ev.get("calibration_set") and "conformal_certainty" in ev:
        ch["E2"] = (float(ev["conformal_certainty"]), False)
    # DEFECT-11 FIX: E3 uses cheap SEP by default; capped; excluded if not computed
    if "semantic_stability" in ev:
        ch["E3"] = (min(float(ev["semantic_stability"]), E3_CAP), False)
    return ch or {"_": (None, None)}

def check_AX7(ev):
    if "parser_pair_agree" not in ev and "intent_raised" not in ev:
        return {"_": (None, None)}
    schema = 1.0 if (ev.get("parser_pair_agree") and ev.get("schema_valid")) else 0.0
    intent = 1.0 if ev.get("intent_raised") else 0.0
    return {"E1_schema": (schema, True), "E1_intent": (intent, True)}

# ---- U core (v1.1, defect-hardened) ----
FLOOR = 0.99865          # >3 sigma one-sided
DELTA = 0.05          # obfuscation slack [UNVERIFIED]
E3_CAP = 0.98        # semantic-stability alone cannot exceed this [UNVERIFIED]
UNCALIBRATED = True  # D5/D5': while True, statistical channels cannot clear the floor alone

def cert_level(channels):
    """channels: dict name -> (value, is_deterministic) ; value None = NOT APPLICABLE (excluded).
    Returns (certainty, det_at_min) or (None, None) when NO channel applies (-> ABSTAIN).
    DEFECT-1/2/3 FIX: not-applicable is EXCLUDED, never coerced to 1.0; empty -> None -> ABSTAIN."""
    applicable = [(v, det) for (v, det) in channels.values() if v is not None]
    if not applicable:
        return (None, None)
    val, det = min(applicable, key=lambda t: t[0])
    return (val, det)

def precision_extract(candidate_text):
    """DEFECT-4 FIX: pi is computed RUNNER-SIDE from the candidate, never supplied by the producer.
    Deterministic proxy: specificity up, hedges down. (Illustrative; real impl = calibrated extractor.)"""
    t = candidate_text.lower()
    hedges = sum(t.count(h) for h in ("might","maybe","possibly","unclear","approximately","i think","unverified","roughly"))
    import re
    specifics = len(re.findall(r"\d+(?:\.\d+)?%?", t)) + t.count("exactly") + t.count("precisely")
    raw = 0.5 + 0.1*specifics - 0.15*hedges
    return max(0.0, min(1.0, raw))

def gate(cert_by_level, candidate_text):
    """Fail-closed emission gate (hosted at BX1 = the Reconciler decision procedure, DEFECT-6/7 FIX:
    single authority, not a parallel gate). Returns exit + limiting level."""
    # DEFECT-2 FIX: a genuinely uncomputable level -> ABSTAIN (distinct from low-but-computable -> RAISE)
    for lvl,(v,det) in cert_by_level.items():
        if v is None:
            return {"exit":"ABSTAIN","reason":"no computable channel","limiting_level":lvl}
    C = min(v for (v,det) in cert_by_level.values())
    limiting = min(cert_by_level, key=lambda k: cert_by_level[k][0])
    det_at_min = cert_by_level[limiting][1]
    pi = precision_extract(candidate_text)   # external, not producer-supplied
    if pi > C + DELTA:
        return {"exit":"CONTAIN","reason":"obfuscation pi>s+delta","pi":round(pi,3),"s":round(C,3),"limiting_level":limiting}
    # DEFECT-5 FIX (uncalibrated fail-safe): until calibration, the floor may be cleared ONLY by a
    # deterministic (E1/verifier/schema/runner) channel at the limiting level; statistical certainty -> RAISE.
    if C >= FLOOR and (not UNCALIBRATED or det_at_min):
        return {"exit":"EMIT","C":round(C,3),"limiting_level":limiting}
    reason = "below floor" if C < FLOOR else "uncalibrated statistical certainty -> not auto-emittable"
    # DEFECT-14 FIX: RAISE returns an enforceable forcing object; runner MUST block auto-accept.
    return {"exit":"RAISE","C":round(C,3),"limiting_level":limiting,"reason":reason,
             "forcing":{"show":["C","limiting_level","channel_provenance"],
                        "require":"explicit owner justification-for-acceptance",
                        "auto_accept_forbidden":True}}


if __name__=="__main__":
    def cl(ch): return cert_level(ch)
    # (a) fully deterministic, supported -> EMIT
    good={"L0":cl(check_L0({"owner_verbatim":True})),
          "7POF":cl(check_7POF({"exemplar_present":True})),
          "AX7":cl(check_AX7({"parser_pair_agree":True,"schema_valid":True,"intent_raised":True})),
          "BX1":cl(check_BX1({"runner_settled":True}))}
    print("(a) deterministic supported:", gate(good,"the runner settled this exactly at 3 references"))
    # (b) relies on uncalibrated statistical E2 to clear floor -> RAISE (fail-safe)
    stat={"L0":cl(check_L0({"owner_verbatim":True})),
          "7POF":cl(check_7POF({"exemplar_present":False,"calibration_set":True,"conformal_certainty":0.999})),
          "AX7":cl(check_AX7({"parser_pair_agree":True,"schema_valid":True,"intent_raised":True})),
          "BX1":cl(check_BX1({"runner_settled":True}))}
    print("(b) statistical-only limiting (uncalib):", gate(stat,"probably around 0.999")["exit"])
    # (c) a level with no applicable channel -> ABSTAIN (not falsely 1.0)
    miss=dict(good); miss["BX1"]=cl(check_BX1({}))
    print("(c) no channel at BX1:", gate(miss,"x")["exit"])
    # (d) obfuscation: confident precise text but weak support
    weak=dict(good); weak["7POF"]=cl(check_7POF({"exemplar_present":False,"semantic_stability":0.5}))
    print("(d) obfuscation:", gate(weak,"exactly 42.0% precisely, no doubt")["exit"])
